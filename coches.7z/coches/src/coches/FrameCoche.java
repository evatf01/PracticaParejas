
package coches;

import java.awt.*;


import java.io.*;
import java.text.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.*;



public class FrameCoche extends javax.swing.JFrame {

    private Component frame;

    
    public FrameCoche() {
        initComponents();
        
        JFrame frame= new JFrame();
        
       
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
       
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);    
        
    }

     ArrayList <Coche> coches = new ArrayList();
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtId = new javax.swing.JFormattedTextField();
        txtNombre = new javax.swing.JFormattedTextField();
        txtPrecio = new javax.swing.JFormattedTextField();
        txtFecha = new javax.swing.JFormattedTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(232, 250, 255));
        jPanel1.setMinimumSize(new java.awt.Dimension(1920, 1080));
        jPanel1.setName(""); // NOI18N
        jPanel1.setLayout(null);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Introduce ID");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel1.setOpaque(true);
        jPanel1.add(jLabel1);
        jLabel1.setBounds(50, 40, 200, 40);

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Introduce nombre");
        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel2.setOpaque(true);
        jPanel1.add(jLabel2);
        jLabel2.setBounds(50, 110, 200, 40);

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Introduce precio");
        jLabel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel3.setOpaque(true);
        jPanel1.add(jLabel3);
        jLabel3.setBounds(50, 180, 200, 40);

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Introduce fecha");
        jLabel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabel4.setOpaque(true);
        jPanel1.add(jLabel4);
        jLabel4.setBounds(50, 260, 200, 40);

        txtId.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));
        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });
        txtId.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtIdKeyTyped(evt);
            }
        });
        jPanel1.add(txtId);
        txtId.setBounds(300, 40, 290, 40);

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreKeyTyped(evt);
            }
        });
        jPanel1.add(txtNombre);
        txtNombre.setBounds(300, 110, 290, 40);

        txtPrecio.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.00"))));
        txtPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecioActionPerformed(evt);
            }
        });
        txtPrecio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPrecioKeyTyped(evt);
            }
        });
        jPanel1.add(txtPrecio);
        txtPrecio.setBounds(300, 180, 290, 40);

        try {
            txtFecha.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##-##-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFechaActionPerformed(evt);
            }
        });
        txtFecha.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtFechaKeyTyped(evt);
            }
        });
        jPanel1.add(txtFecha);
        txtFecha.setBounds(300, 260, 290, 40);

        jButton1.setBackground(new java.awt.Color(204, 204, 204));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coches/checkObj.png"))); // NOI18N
        jButton1.setText("Crear Coche");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(100, 370, 130, 80);

        jButton2.setBackground(new java.awt.Color(204, 204, 204));
        jButton2.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/coches/archivo.png"))); // NOI18N
        jButton2.setText("GenerarFichero");
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(500, 370, 130, 80);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(-40, -30, 1410, 790);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed

        
    }//GEN-LAST:event_txtIdActionPerformed

    private void txtFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechaActionPerformed
      
    

    }//GEN-LAST:event_txtFechaActionPerformed
   
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      
       
        if(txtId.getText().isEmpty() || txtNombre.getText().isEmpty() || txtPrecio.getText().isEmpty() || txtFecha.getText().isEmpty()){
            JOptionPane.showMessageDialog(frame,"Hay algun campo vacio","Mensaje", JOptionPane.INFORMATION_MESSAGE);
   	 }                                      
        else{
            
            int id=Integer.parseInt(txtId.getText());
            
               if (comprobarId(id)==false) {
                  JOptionPane.showMessageDialog(this,"Este coche ya existe","Mensaje",JOptionPane.INFORMATION_MESSAGE);
                    
                txtId.setText("");
                txtNombre.setText("");
                txtPrecio.setText("");
                txtFecha.setText("");
            }
               else{
                try { 
                    SimpleDateFormat formato = new SimpleDateFormat("dd-MM-yy");
                    Date fecha = formato.parse(txtFecha.getText());
                    
                    Double precio = Double.parseDouble(txtPrecio.getText().replace(",", "."));
                    Coche coche = new Coche (id,txtNombre.getText(),precio,fecha);
                    coches.add(coche);
                   
                    
                    JOptionPane.showMessageDialog(frame,"Guardado correctamente","Mensaje", JOptionPane.INFORMATION_MESSAGE);
                    
                } catch (ParseException ex) {
                   JOptionPane.showInputDialog(this,ex.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
                }
          
               }
            
           
    }
           
        

    }//GEN-LAST:event_jButton1ActionPerformed
    
    private void txtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyTyped
        char comprobar =evt.getKeyChar();
        if(Character.isDigit(comprobar)){
            getToolkit().beep();
            evt.consume();
             JOptionPane.showMessageDialog(frame,"Ingrese solo letras","Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        }
                
                
    }//GEN-LAST:event_txtNombreKeyTyped

    private void txtIdKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdKeyTyped
        char comprobar =evt.getKeyChar();
        if(!Character.isDigit(comprobar)){
            getToolkit().beep();
            evt.consume();
             JOptionPane.showMessageDialog(frame,"Ingrese solo numeros","Mensaje", JOptionPane.INFORMATION_MESSAGE);
            
        }
    }//GEN-LAST:event_txtIdKeyTyped

    
    private void txtPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecioActionPerformed

    private void txtPrecioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPrecioKeyTyped
        
    }//GEN-LAST:event_txtPrecioKeyTyped

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtFechaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtFechaKeyTyped
       
       Character letra = evt.getKeyChar();
        if(Character.isLetter(letra)){
            evt.consume();
        }
              
    }//GEN-LAST:event_txtFechaKeyTyped

    
    
    
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
          if(txtId.getText().isEmpty() || txtNombre.getText().isEmpty() || txtPrecio.getText().isEmpty() || txtFecha.getText().isEmpty()){
            JOptionPane.showMessageDialog(frame,"Primero ingrese los datos","Mensaje", JOptionPane.INFORMATION_MESSAGE);
   	 }                                      
          else{

              crearFichero();
             
          }
    }//GEN-LAST:event_jButton2ActionPerformed

   
    
    
    
    public static void main(String args[]) {
        
        new FrameCoche();
    }
   
    public boolean comprobarId(int id){
        boolean unico=true;
        for(Coche co : coches){
            if(id==co.getId()){
                unico=false;
                
            }
        }
        return unico;
    }
    public void crearFichero(){
        String fichero=JOptionPane.showInputDialog(this,"Introduce el nombre del fichero");
        if(fichero.isEmpty()){
            JOptionPane.showMessageDialog(this,"Introduce el nombre");
        }
        else{
            try{
                
                 File file = new File(fichero+".txt");
                 FileOutputStream fos = new FileOutputStream(file);
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                    
                 oos.writeObject(coches);
                 oos.close();
                 fos.close();
            
            }
            catch(IOException ex){
                 JOptionPane.showMessageDialog(this,ex.getMessage(),"mensaje",JOptionPane.INFORMATION_MESSAGE);
            }
            
            JOptionPane.showMessageDialog(this,"Guardado","Mensaje",JOptionPane.INFORMATION_MESSAGE);
             txtId.setText("");
              txtNombre.setText("");
              txtPrecio.setText("");
              txtFecha.setText("");
        }
    }    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JFormattedTextField txtFecha;
    private javax.swing.JFormattedTextField txtId;
    private javax.swing.JFormattedTextField txtNombre;
    private javax.swing.JFormattedTextField txtPrecio;
    // End of variables declaration//GEN-END:variables

  
    
    
}
