/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coches;

import java.io.Serializable;
import java.util.Date;

public class Coche implements Serializable {
       int id;
       String nombre;
       Date fecha;
       Double precio;

    public Coche(int id, String nom, Double precio,Date fecha){
       this.id=id;
       this.nombre=nom;
       this.precio=precio;
       this.fecha=fecha;
}


    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Date getFecha() {
        return fecha;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
       @Override
    public String toString(){
        return " id: "+this.id+" nombre: "+this.nombre+" precio: "+this.precio+" fecha: "+this.fecha;
     }
}
